<?php if($active): ?>
    <?php if($layout == 'body'): ?>
        <?php if($widgetData['layout_type'] == 'two-column'): ?>
            <?php if (isset($component)) { $__componentOriginalb1b2682d87cd0a2327c09f4df7baa7b4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb1b2682d87cd0a2327c09f4df7baa7b4 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Video\TwoColumn::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('video::two-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Video\TwoColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb1b2682d87cd0a2327c09f4df7baa7b4)): ?>
<?php $attributes = $__attributesOriginalb1b2682d87cd0a2327c09f4df7baa7b4; ?>
<?php unset($__attributesOriginalb1b2682d87cd0a2327c09f4df7baa7b4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb1b2682d87cd0a2327c09f4df7baa7b4)): ?>
<?php $component = $__componentOriginalb1b2682d87cd0a2327c09f4df7baa7b4; ?>
<?php unset($__componentOriginalb1b2682d87cd0a2327c09f4df7baa7b4); ?>
<?php endif; ?>
        <?php elseif($widgetData['layout_type'] == 'one-column'): ?>
            <?php if (isset($component)) { $__componentOriginal152949fc503b81726b11e52b27cabac7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal152949fc503b81726b11e52b27cabac7 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Video\OneColumn::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('video::one-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Video\OneColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal152949fc503b81726b11e52b27cabac7)): ?>
<?php $attributes = $__attributesOriginal152949fc503b81726b11e52b27cabac7; ?>
<?php unset($__attributesOriginal152949fc503b81726b11e52b27cabac7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal152949fc503b81726b11e52b27cabac7)): ?>
<?php $component = $__componentOriginal152949fc503b81726b11e52b27cabac7; ?>
<?php unset($__componentOriginal152949fc503b81726b11e52b27cabac7); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/video.blade.php ENDPATH**/ ?>