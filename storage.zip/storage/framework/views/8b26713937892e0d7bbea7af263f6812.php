<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $postHelper = app('App\Helpers\PostHelper'); ?>
<?php $posts->each(function ($posts) {$posts->load('categories'); }); ?>

<?php if($posts->isNotEmpty()): ?>
<?php if($active): ?>
<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
<h1 class="title-col">
    <?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?>

    <div class="carousel-nav" id="hot-news-nav">
        <div class="prev">
            <span class="arrow-left"></span>
        </div>
        <div class="next">
            <span class="arrow-right"></span>
        </div>
    </div>
</h1>
<?php endif; ?>
<div class="body-col vertical-slider" data-max="4" data-nav="#hot-news-nav" data-item="article">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="article-mini">
            <div class="inner">
                <figure>
                    <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                        <img src="<?php echo e($postHelper::showThumbnail($post, '80')); ?>"
                             alt="<?php echo e($post->post_image); ?>">
                    </a>
                </figure>
                <div class="padding">
                    <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a></h1>
                    <div class="detail">
                        <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                            <div class="category">
                                <a href="<?php echo e(route('category.show', $post->categories->first()->slug)); ?>">
                                <?php echo e($post->categories->first()->name); ?>

                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                    </div>
                </div>
            </div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php endif; ?>

<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/mini-post.blade.php ENDPATH**/ ?>