<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['page','widgetName','widgetData','localeId']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['page','widgetName','widgetData','localeId']); ?>
<?php foreach (array_filter((['page','widgetName','widgetData','localeId']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal9d110c289c4f93ce9580a56212288cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d110c289c4f93ce9580a56212288cbe = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Footer\PostFooter::resolve(['page' => $page,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('post-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Footer\PostFooter::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d110c289c4f93ce9580a56212288cbe)): ?>
<?php $attributes = $__attributesOriginal9d110c289c4f93ce9580a56212288cbe; ?>
<?php unset($__attributesOriginal9d110c289c4f93ce9580a56212288cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d110c289c4f93ce9580a56212288cbe)): ?>
<?php $component = $__componentOriginal9d110c289c4f93ce9580a56212288cbe; ?>
<?php unset($__componentOriginal9d110c289c4f93ce9580a56212288cbe); ?>
<?php endif; ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\storage\framework\views/d506864abf9ff320aa821ee259565156.blade.php ENDPATH**/ ?>