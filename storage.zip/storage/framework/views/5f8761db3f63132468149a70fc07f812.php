<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
<h1 class="block-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?> <div class="right"></div></h1>
<?php endif; ?>
<div class="block-body">
    <?php if($widgetData['description'] && Arr::exists($widgetData['description'], LaravelLocalization::getCurrentLocale())): ?>
    <p><?php echo e($widgetData['description'][LaravelLocalization::getCurrentLocale()]); ?></p>
    <?php endif; ?>
    <ul class="tags">
        <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('tag.show', $term->slug)); ?>"><?php echo e($term->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/footer/box-label.blade.php ENDPATH**/ ?>