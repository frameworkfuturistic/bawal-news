

<?php $__env->startSection('title', __('Web Information')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('title.web_backup')).'','currentActive' => ''.e(__('title.web_backup')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                <div class="form-group">
        <label><?php echo e(__('form.export')); ?></label>
        <div>
            <button type="button" id="btn-export" class="btn btn-info">
                <i class="fas fa-file-excel"></i> <?php echo e(__('button.download_data')); ?>

            </button>
            <button type="button" id="btn-export-storage" class="btn btn-info">
                <i class="fas fa-download"></i> <?php echo e(__('button.download_backup')); ?>

            </button>
        </div>
    </div>
    <hr>
    <form id="formUploadImport" action="<?php echo e(route('import')); ?>" method="POST" role="form" enctype="multipart/form-data">
        <?php echo method_field('POST'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for=""><?php echo e(__('form.import')); ?></label><br>
            <div class="input-group">
                <div class="custom-file">
                    <input id="InputFileBackup" type="file" name="import" class="custom-file-input" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
                    <label class="custom-file-label"><?php echo e(__('form.placeholder_import')); ?></label>
                </div>
            </div>
            <p>
                <small>
                    <?php echo e(__('form.help_import')); ?><br>
                </small>
            </p>
        </div>
        <button id="uploadFileBackup" type="submit" class="btn btn-info" disabled>
            <?php echo e(__('button.upload')); ?>

        </button>
    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('admin.settings._style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._csrf-token', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.languages._languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        "use strict";

        $('input[type=file]#InputFileBackup').change(function() {
            if($('input[type=file]#inputFileBackup').val()==''){
                $('button#uploadFileBackup').attr('disabled',true)
            }
            else{
                $('button#uploadFileBackup').attr('disabled',false);
            }
        });

        $(document).on("click", "#btn-export", function(e) {
            e.preventDefault();
            $("#btn-export").html("<div class=\"spinner-grow spinner-grow-sm\" role=\"status\"><span class=\"sr-only\"><?php echo e(__('message.loading')); ?></span></div> <?php echo e(__('message.sending')); ?>");
            $.ajax({
                url: "<?php echo e(route('export')); ?>",
                method: "GET",
                xhrFields: {
                    responseType: 'blob'
                },
                success: function(response){
                    let name = "<?php echo e(config('retenvi.app_name')); ?>";
                    let version = "<?php echo e(config('retenvi.version')); ?>";
                    let ext = ".xlsx";
                    let filename = name + "-v" + version + ext;
                    let blob = new Blob([response]);
                    let link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = filename;
                    link.click();
                    $(".spinner-grow").attr("hidden", true);
                    $("#btn-export").html("<i class='fas fa-file-excel'></i> <?php echo e(__('button.download_data')); ?>");
                }
            });
        })

        $(document).on("click", "#btn-export-storage", function(e) {
            e.preventDefault();
            $("#btn-export-storage").html("<div class=\"spinner-grow spinner-grow-sm\" role=\"status\"><span class=\"sr-only\"><?php echo e(__('message.loading')); ?></span></div> <?php echo e(__('message.sending')); ?>");
            $.ajax({
                url: "<?php echo e(route('export.storage')); ?>",
                method: "GET",
                cache: false,
                xhrFields: {
                    responseType: 'blob'
                },
                success: function(response){
                    let name = "<?php echo e(config('retenvi.app_name')); ?>";
                    let version = "<?php echo e(config('retenvi.version')); ?>";
                    let ext = "storage.zip";
                    let filename = name + "-v" + version + "-" + ext;
                    let blob = new Blob([response]);
                    let link = document.createElement('a');
                    link.href = window.URL.createObjectURL(blob);
                    link.download = filename;
                    link.click();
                    $(".spinner-grow").attr("hidden", true);
                    $("#btn-export-storage").html("<i class='fas fa-file-excel'></i> <?php echo e(__('button.download_data')); ?>");
                }
            });
        })

        $(document).on("click", "#uploadFileBackup", function(e) {
            e.preventDefault();
            $("#uploadFileBackup").html("<div class=\"spinner-grow spinner-grow-sm\" role=\"status\"><span class=\"sr-only\"><?php echo e(__('message.loading')); ?></span></div> <?php echo e(__('message.sending')); ?>");
            let url = $("#formUploadImport").attr("action");
            var form = $('#formUploadImport')[0];
            var data = new FormData(form);
            $.ajax({
                type: 'post',
                processData: false,
                contentType: false,
                enctype: "multipart/form-data",
                url: url,
                data: data,
                success: function(response) {
                    $(".spinner-grow").attr("hidden", true);
                    $("#formUploadImport")[0].reset();
                    $("#uploadFileBackup").html("<?php echo e(__('button.upload')); ?>");
                    if (response.errors) {
                        toastr.error(response.errors.import);
                    } else if (response.info) {
                        toastr.info(response.info);
                    } else {
                        toastr.success(response.success);
                    }
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/settings/web-backup.blade.php ENDPATH**/ ?>