<?php $__env->startSection('title', __('title.dashboard')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('title.dashboard')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-posts')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('posts.index')); ?>">
                    <div class="info-box">
                        <span class="info-box-icon bg-info elevation-1"><i class="fas fa-book"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.posts')); ?></span>
                            <span class="info-box-number"><?php echo e($count->post); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-pages')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('pages.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-danger elevation-1"><i class="fas fa-copy"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.pages')); ?></span>
                            <span class="info-box-number"><?php echo e($count->page); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <div class="clearfix hidden-md-up"></div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-categories')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('categories.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-success elevation-1"><i class="fas fa-tags"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.categories')); ?></span>
                            <span class="info-box-number"><?php echo e($count->category); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-tags')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('tags.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-warning elevation-1"><i class="fas fa-thumbtack"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.tags')); ?></span>
                            <span class="info-box-number"><?php echo e($count->tag); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-users')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('users.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-indigo elevation-1"><i class="fas fa-users"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.users')); ?></span>
                            <span class="info-box-number"><?php echo e($count->user); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-roles')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('roles.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-fuchsia elevation-1"><i class="fas fa-user-shield"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.roles')); ?></span>
                            <span class="info-box-number"><?php echo e($count->role); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-contacts')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('contacts.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-olive elevation-1"><i class="fas fa-envelope"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.contacts')); ?></span>
                            <span class="info-box-number"><?php echo e($count->contact); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-galleries')): ?>
            <div class="col-12 col-sm-6 col-md-3">
                <a class="link-info-box" href="<?php echo e(route('galleries.index')); ?>">
                    <div class="info-box mb-3">
                        <span class="info-box-icon bg-purple elevation-1"><i class="fas fa-hdd"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text"><?php echo e(__('title.galleries')); ?></span>
                            <span class="info-box-number"><?php echo e($count->gallery); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        <?php endif; ?>
    </div>

    <?php if(env('ANALYTICS_PROPERTY_ID')): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-analytics')): ?>
            <?php if(\App\Helpers\SettingHelper::check_connection()): ?>
                <?php if(\App\Helpers\SettingHelper::checkCredentialFileExists()): ?>
                    <h4 class="head-analytics mt-4 mb-4"><span class="title-google-analytics"><?php echo e(__('title.google_analytics')); ?></span> <small class="link-analytics-detail">(<a href="<?php echo e(route('analytics')); ?>"><?php echo e(__('see_more')); ?></a>)</small></h4>
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $__env->make('admin.analytics._device', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                        <div class="col-md-8">
                            <?php echo $__env->make('admin.analytics._visitors_pageviews', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .card {box-shadow: none;border: 1px solid rgba(0, 0, 0, .125);} .link-info-box {color: #000;}
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.analytics._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>