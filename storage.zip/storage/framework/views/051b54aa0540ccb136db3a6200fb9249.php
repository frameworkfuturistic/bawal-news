<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $themeHelper = app('App\Helpers\ThemeHelper'); ?>
<?php $postHelper = app('App\Helpers\PostHelper'); ?>

<?php $__env->startSection('content'); ?>
<section class="single top">
    <div class="container-md">
        <div class="row">
            <?php if($sidebarPosition === "left" AND $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="col-lg-8 <?php if($sidebarActive === false): ?> offset-lg-2 <?php endif; ?>">
            <?php if($post->post_title): ?>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/"><?php echo e(__('Laramagz::magz.home')); ?></a></li>
                    <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($post->terms()->category()->first()->name); ?></li>
                    <?php endif; ?>
                </ol>
                <article class="article main-article">
                    <header>
                        <h1><?php echo e($post->post_title); ?></h1>
                        <ul class="details">
                            <li><?php echo e(__('Laramagz::magz.posted_on')); ?> <?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></li>
                            <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                <li>
                                    <a href="<?php echo e($termHelper->resolveUrl($post, $post->terms()->category()->first()->slug)); ?>">
                                        <?php echo e($termHelper->resolveLabel($post, $post->terms()->category()->first()->slug)); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                            <li><?php echo e(__('Laramagz::magz.by')); ?> <span><?php echo e($post->user->name); ?></span></li>
                            <li><?php echo e($post->post_hits); ?> <?php echo e(__('Laramagz::magz.views')); ?></li>
                        </ul>
                    </header>
                    <div class="main">
                        <div class="summary">
                        <?php echo $post->post_summary; ?>

                        </div>
                        <?php if($post->post_type == "page" OR $post->post_type == "post"): ?>
                            <?php if(!empty($post->post_image) && App\Helpers\ImageHelper::isExists('images', $post->post_image) || App\Helpers\PostHelper::isImageUrlAvailable($post)): ?>
                            <figure class="figure d-block text-center mb-4">
                                <img src="<?php echo e($postHelper->displayThumbnailForSinglePost($post)); ?>" class="figure-img img-fluid rounded" alt="<?php echo e($post->post_image); ?>" width="736" height="552">
                                <figcaption class="figure-caption"><?php echo $postHelper->getPostThumbnailCaption($post->post_image_meta); ?></figcaption>
                            </figure>
                            <?php else: ?>
                            <hr>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php
                                $postSource = json_decode($post->post_source);
                                $postImageMeta = $postHelper->isImageUrlAvailable($post);

                                if ($postImageMeta) {
                                    $poster = json_decode($post->post_image_meta)->image_url;
                                } else {
                                    $poster = ($post->post_image) ? asset('storage/images/'.$post->post_image) : asset('img/cover-video.webp');
                                }
                            ?>
                            <?php if($post->post_type == "video_embed" OR $post->post_type == "audio_embed"): ?>
                                <?php if($post->post_type == "video_embed"): ?>
                                    <figure class="player">  
                                        <div id="player" data-plyr-provider="<?php echo e($postSource->provider); ?>" data-plyr-embed-id="<?php echo e($postSource->embed_id); ?>" data-poster="<?php echo e($poster); ?>" style="--plyr-color-main: #eb0254;"></div>
                                    </figure>
                                <?php elseif($post->post_type == "audio_embed"): ?>
                                <div class="plyr__audio-embed" id="player" style="--plyr-color-main: #eb0254; margin-bottom: 3rem;">
                                    <?php echo $post->post_source; ?>

                                </div>
                                <?php endif; ?>
                            <?php elseif($post->post_type == "audio_file" OR $post->post_type == "audio_url"): ?>
                                <?php
                                    $postSource = json_decode($post->post_source);
                                    $postImageMeta = $postHelper->isImageUrlAvailable($post);

                                    $poster = '';

                                    if ($post->post_image ) {
                                        if ($postImageMeta) {
                                            $poster = json_decode($post->post_image_meta)->image_url;
                                        } else {
                                            $poster = asset('storage/images/'.$post->post_image);
                                        }
                                    }
                                ?>
                                <?php if(!empty($poster)): ?>
                                    <div class="featured">
                                        <figure>
                                            <img src="<?php echo e($poster); ?>" alt="<?php echo e($post->post_title); ?>">
                                        </figure>
                                    </div>
                                <?php endif; ?>
                                <div class="container-plyr mt-3 mb-5">
                                    <?php
                                    $source = ($post->post_type == 'audio_file') ? asset('storage/audios/'.$post->post_source) : $post->post_source;
                                    ?>
                                    <audio id="player" style="--plyr-color-main: #eb0254;" controls>
                                        <source src="<?php echo e($source); ?>"/>
                                    </audio>
                                </div>
                            <?php elseif($post->post_type == "video_url"): ?>
                                <?php
                                    $poster = ($post->post_image) ? asset('storage/images/'.$post->post_image) : asset('img/cover-video.webp');
                                ?>
                                <figure class="player">
                                    <div id="player" data-plyr-provider="youtube" data-poster="<?php echo e($poster); ?>" data-plyr-embed-id="<?php echo e($post->post_source); ?>" style="--plyr-color-main: #eb0254;"></div>
                                </figure>
                            <?php else: ?>
                                <div class="container-plyr mb-5">
                                    <?php
                                    $width = ($post->post_type == "video_file") ? '100%' : '640';
                                    $poster = ($post->post_image) ? asset('storage/images/'.$post->post_image) : asset('img/cover-video.webp');
                                    ?>
                                    <figure>
                                    <video id="player" playsinline controls data-plyr-config='{ "ratio": "16:9" }' data-poster="<?php echo e($poster); ?>" style="--plyr-color-main: #eb0254;">
                                        <source src="<?php echo e(asset('storage/videos/'.$post->post_source)); ?>"/>
                                    </video>
                                    </figure>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                             
                        <?php echo $post->post_content; ?>

                    </div>
                    <footer>
                        <div class="col-m">
                            <ul class="tags">
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('tag.show', $tag)); ?>"><?php echo e($tag->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="col-m">
                            <span class="love" data-id="<?php echo e($hashids->encode($post->id)); ?>"><i class="fa-regular fa-thumbs-up"></i>
                                <div><?php echo e($post->like); ?></div>
                            </span>
                        </div>
                    </footer>
                </article>
                <div class="sharing">
                    <div class="title"><i class="ion-android-share-alt"></i> <?php echo e(__('Laramagz::magz.sharing_is_caring')); ?></div>
                    <?php echo Share::page(request()->url(), $post->post_title, [], '<ul class="social">', '</ul>')
                    ->facebook()
                    ->twitter()
                    ->linkedin()
                    ->whatsapp()
                    ->telegram(); ?>

                </div>
                <div class="line">
                    <div><?php echo e(__('Laramagz::magz.author')); ?></div>
                </div>
                <div class="author">
                    <figure>
                        <?php if($post->user->photo): ?>
                            <?php if($post->user->photo): ?>
                                <?php if(\App\Helpers\ImageHelper::isExists('avatar', $post->user->photo)): ?>
                                    <img src="<?php echo e(asset('storage/avatar/'.$post->user->photo)); ?>" alt="<?php echo e($post->user->name); ?>" width="100" height="100">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('img/noavatar.png')); ?>" alt="<?php echo e(__('Laramagz::magz.no_image')); ?>" width="100" height="100">
                                <?php endif; ?>
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/noavatar.png')); ?>" alt="<?php echo e(__('Laramagz::magz.no_image')); ?>" width="100" height="100">
                            <?php endif; ?>
                        <?php else: ?>
                            <img src="<?php echo e(asset('img/noavatar.png')); ?>" alt="<?php echo e(__('Laramagz::magz.no_image')); ?>" width="100" height="100">
                        <?php endif; ?>
                    </figure>
                    <div class="details">
                        <?php if($post->user->occupation): ?> <div class="job"><?php echo e($post->user->occupation); ?></div> <?php endif; ?>
                        <div class="name"><?php echo e($post->user->name); ?></div>
                        <p><?php if($post->user->about): ?> <?php echo e($post->user->about); ?> <?php endif; ?></p>

                        <?php if($post->user->links): ?>
                            <ul class="social trp sm">
                                <?php $__currentLoopData = json_decode($post->user->links); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e($link->url); ?>" aria-label="<?php echo e($link->label); ?>" target="_blank" style="background-color: <?php echo e($link->color); ?>;color:#fff">
                                            <i class="<?php echo e($link->icon); ?>"></i>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if (isset($component)) { $__componentOriginalb11a870e530258d595732703115b09b8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb11a870e530258d595732703115b09b8 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\RelatedPost::resolve(['mainPostTitle' => $post->post_title,'page' => $page,'post' => $post,'layout' => 'body','widgetName' => 'related_post','widgetData' => $relatedPost] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('related-post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\RelatedPost::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb11a870e530258d595732703115b09b8)): ?>
<?php $attributes = $__attributesOriginalb11a870e530258d595732703115b09b8; ?>
<?php unset($__attributesOriginalb11a870e530258d595732703115b09b8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb11a870e530258d595732703115b09b8)): ?>
<?php $component = $__componentOriginalb11a870e530258d595732703115b09b8; ?>
<?php unset($__componentOriginalb11a870e530258d595732703115b09b8); ?>
<?php endif; ?>
                <div class="line thin"></div>
                <?php echo $__env->make('frontend.magz.inc._comment-disqus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('frontend.magz.inc._comment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            </div>
            <?php if($sidebarPosition === "right" AND $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/prism.js/prism.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/plyr/plyr.min.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('vendor/prism.js/prism.js')); ?>"></script>
    <script src="<?php echo e(asset('js/share.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plyr/plyr.min.js')); ?>"></script>

    <script>
        const player = new Plyr('#player');
    </script>

    <script>
        var commentModal = document.getElementById('commentModal')
        commentModal.addEventListener('hidden.bs.modal', function (event) {
            var url = '<?php echo e(route("comment")); ?>';
            $('input[name="_method"]').detach();
            $("#comment").val('');
            $('#replyId').val('');
            $('#mainReply').val('');
            $('#name').val('');
            $('#email').val('');
            $('#url').val('');
            $('.comment-form').attr('action', url);
            $('.comment-form').attr('data-action', '');
            $('.form-control').removeClass('is-invalid');
            $('#comment-submit').html("<?php echo e(__('Laramagz::magz.send_response')); ?>");
            $(".spinner-grow").attr("hidden");  
        })
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.magz.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/page/single.blade.php ENDPATH**/ ?>