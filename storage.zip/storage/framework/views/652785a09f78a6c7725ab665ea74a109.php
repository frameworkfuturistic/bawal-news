<?php $videoHelper = app('App\Helpers\VideoHelper'); ?>
<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $posts->each(function ($posts) {$posts->load('categories'); }); ?>

<?php if($posts->isNotEmpty()): ?>
<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
    <div class="line top">
        <div><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></div>
    </div>
<?php endif; ?>
<div class="row">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
            <article class="article col-lg-12">
                <div class="inner">
                    <figure>
                        <a href="<?php echo e($videoHelper->getUriPost($post)); ?>" aria-label="read more">
                            <img src="<?php echo e($videoHelper->showThumbnail($post, 356)); ?>"
                                 alt="<?php echo e($post->post_image); ?>">
                            <div class="link-icon"><i class="fas fa-play"></i></div>
                        </a>
                    </figure>
                    <div class="padding">
                        <div class="detail">
                            <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                            <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                <div class="category">
                                    <a href="<?php echo e(route('category.show', $post->categories->first()->slug)); ?>">
                                    <?php echo e($post->categories->first()->name); ?>

                                    </a>
                                </div>
                            <?php endif; ?>
                            <div class="view"><?php echo e($post->post_hits); ?> <?php echo e(__('Laramagz::magz.views')); ?> &nbsp; <?php echo e($post->like); ?> <?php echo e(__('Laramagz::magz.likes')); ?></div>
                        </div>
                        <h2><a href="<?php echo e($videoHelper->getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a></h2>
                        <p><?php echo \Str::limit(strip_tags($post->post_content), 150); ?></p>
                    </div>
                </div>
            </article>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/video/two-column.blade.php ENDPATH**/ ?>