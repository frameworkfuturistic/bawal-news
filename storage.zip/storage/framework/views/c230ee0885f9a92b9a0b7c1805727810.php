<?php $__env->startSection('title_prefix', __('auth.login')); ?>
<?php $__env->startSection('title', ' - '. strip_tags(config('adminlte.logo'))); ?>

<?php echo $__env->make('adminlte::auth.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/auth/login.blade.php ENDPATH**/ ?>