<?php $themeHelper = app('App\Helpers\ThemeHelper'); ?>

<?php $__env->startSection('content'); ?>
<section class="home top">
    <div class="container-md">
        <div class="row" style="margin-top: 56px">
            <?php if($sidebarPosition === "left" AND $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div style="background-color: #eff3f6;" class="col-lg-8 col-md-12 col-sm-12 col <?php if($sidebarActive === false): ?> offset-lg-2 <?php endif; ?>">
                <?php $__currentLoopData = $body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $widgetName => $widgetData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($widgetName != 'bottom_post'): ?>
                        <?php if(Arr::first(Str::of($widgetName)->explode('-')) == 'section'): ?>
                            <?php if($widgetData['active'] == 'true'): ?>
                            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $themeHelper->getComponentName($widgetName)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'home','layout' => 'body','widgetName' => $widgetName,'widgetData' => $widgetData['widget'],'localeId' => $localeId]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($widgetData['active'] == 'true'): ?>
                            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $themeHelper->getComponentName($widgetName)] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\DynamicComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'home','layout' => 'body','widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($sidebarPosition === "right" AND $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php if($bottomPostActive): ?>
    <?php if (isset($component)) { $__componentOriginal21476036dcfb8804041d4c2120ac7d65 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal21476036dcfb8804041d4c2120ac7d65 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\BottomPost::resolve(['widgetData' => $bottomPost,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('bottom-post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\BottomPost::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal21476036dcfb8804041d4c2120ac7d65)): ?>
<?php $attributes = $__attributesOriginal21476036dcfb8804041d4c2120ac7d65; ?>
<?php unset($__attributesOriginal21476036dcfb8804041d4c2120ac7d65); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal21476036dcfb8804041d4c2120ac7d65)): ?>
<?php $component = $__componentOriginal21476036dcfb8804041d4c2120ac7d65; ?>
<?php unset($__componentOriginal21476036dcfb8804041d4c2120ac7d65); ?>
<?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let $target_end=$(".best-of-the-week");
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.magz.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/page/home.blade.php ENDPATH**/ ?>