<?php if($terms->isNotEmpty()): ?>
<?php if($active): ?>
<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
    <h1 class="title-col"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
<?php endif; ?>
<div class="body-col">
    <ol class="tags-list">
        <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($widgetData['term_type'] == 'tags'): ?>
                <li><a href="<?php echo e(route('tag.show', $term->slug)); ?>"><?php echo e($term->name); ?></a></li>
            <?php else: ?>
                <li><a href="<?php echo e(route('categories.show', $term->slug)); ?>"><?php echo e($term->name); ?></a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</div>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/list-label.blade.php ENDPATH**/ ?>