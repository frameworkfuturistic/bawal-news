<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?><h1 class="block-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1><?php endif; ?>
<div class="block-body">
    <?php if($widgetData['logo'] == 'true'): ?>
    <figure class="foot-logo">
        <img src="<?php echo e(\App\Helpers\ImageHelper::webLogoLight()); ?>" alt="Web Logo" width="140" height="44">
    </figure>
    <?php endif; ?>
    <p class="brand-description">
        <?php echo e(config('settings.site_description')); ?>

    </p>
    <?php if($widgetData['link'] == 'true'): ?>
    <a href="<?php echo e(route('page.show', 'about')); ?>" class="btn btn-magz white" aria-label="<?php echo e(__('Laramagz::magz.about_us')); ?>"><?php echo e(__('Laramagz::magz.about_us')); ?> &#8594;</a>
    <?php endif; ?>
</div>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/footer/about-footer.blade.php ENDPATH**/ ?>