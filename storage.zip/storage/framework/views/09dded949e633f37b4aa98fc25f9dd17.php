<?php if($active): ?>
    <?php if($layout == 'body'): ?>
        <?php if($widgetData['layout_type'] == 'two-column'): ?>
            <?php if (isset($component)) { $__componentOriginalc677aa1c8925f18dccfa1fb3b7abbaf5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc677aa1c8925f18dccfa1fb3b7abbaf5 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Post\TwoColumn::resolve(['widgetData' => $widgetData,'page' => $page,'layout' => $layout,'widgetName' => $widgetName,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('post::two-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Post\TwoColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc677aa1c8925f18dccfa1fb3b7abbaf5)): ?>
<?php $attributes = $__attributesOriginalc677aa1c8925f18dccfa1fb3b7abbaf5; ?>
<?php unset($__attributesOriginalc677aa1c8925f18dccfa1fb3b7abbaf5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc677aa1c8925f18dccfa1fb3b7abbaf5)): ?>
<?php $component = $__componentOriginalc677aa1c8925f18dccfa1fb3b7abbaf5; ?>
<?php unset($__componentOriginalc677aa1c8925f18dccfa1fb3b7abbaf5); ?>
<?php endif; ?>
        <?php elseif($widgetData['layout_type'] == 'one-column'): ?>
            <?php if (isset($component)) { $__componentOriginalf0c2a47e673cfc490c9444be0e7bb44e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf0c2a47e673cfc490c9444be0e7bb44e = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Post\OneColumn::resolve(['widgetData' => $widgetData,'page' => $page,'layout' => $layout,'widgetName' => $widgetName,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('post::one-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Post\OneColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf0c2a47e673cfc490c9444be0e7bb44e)): ?>
<?php $attributes = $__attributesOriginalf0c2a47e673cfc490c9444be0e7bb44e; ?>
<?php unset($__attributesOriginalf0c2a47e673cfc490c9444be0e7bb44e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf0c2a47e673cfc490c9444be0e7bb44e)): ?>
<?php $component = $__componentOriginalf0c2a47e673cfc490c9444be0e7bb44e; ?>
<?php unset($__componentOriginalf0c2a47e673cfc490c9444be0e7bb44e); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/post.blade.php ENDPATH**/ ?>