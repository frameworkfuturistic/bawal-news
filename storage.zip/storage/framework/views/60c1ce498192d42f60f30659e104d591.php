<?php if($active): ?>
<?php if($widgetData['ad_type'] == "image"): ?>
   <?php if (isset($component)) { $__componentOriginal364228a833d5f278caf166e6274c17d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal364228a833d5f278caf166e6274c17d4 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Ads\Image::resolve(['layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ads::image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Ads\Image::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal364228a833d5f278caf166e6274c17d4)): ?>
<?php $attributes = $__attributesOriginal364228a833d5f278caf166e6274c17d4; ?>
<?php unset($__attributesOriginal364228a833d5f278caf166e6274c17d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal364228a833d5f278caf166e6274c17d4)): ?>
<?php $component = $__componentOriginal364228a833d5f278caf166e6274c17d4; ?>
<?php unset($__componentOriginal364228a833d5f278caf166e6274c17d4); ?>
<?php endif; ?>
<?php elseif($widgetData['ad_type'] == "script"): ?>
   <?php if (isset($component)) { $__componentOriginal30ef0cde4b98c0856ec8bffe0cd22aeb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30ef0cde4b98c0856ec8bffe0cd22aeb = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Ads\Script::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ads::script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Ads\Script::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page),'layout' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($layout),'widgetName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($widgetName),'widgetData' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($widgetData)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30ef0cde4b98c0856ec8bffe0cd22aeb)): ?>
<?php $attributes = $__attributesOriginal30ef0cde4b98c0856ec8bffe0cd22aeb; ?>
<?php unset($__attributesOriginal30ef0cde4b98c0856ec8bffe0cd22aeb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30ef0cde4b98c0856ec8bffe0cd22aeb)): ?>
<?php $component = $__componentOriginal30ef0cde4b98c0856ec8bffe0cd22aeb; ?>
<?php unset($__componentOriginal30ef0cde4b98c0856ec8bffe0cd22aeb); ?>
<?php endif; ?>
<?php else: ?>
   <?php if (isset($component)) { $__componentOriginale556e1dac3f4912fd824239e0c9c3681 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale556e1dac3f4912fd824239e0c9c3681 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Ads\GoogleAdsense::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ads::google-adsense'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Ads\GoogleAdsense::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($page),'layout' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($layout),'widgetName' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($widgetName),'widgetData' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($widgetData)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale556e1dac3f4912fd824239e0c9c3681)): ?>
<?php $attributes = $__attributesOriginale556e1dac3f4912fd824239e0c9c3681; ?>
<?php unset($__attributesOriginale556e1dac3f4912fd824239e0c9c3681); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale556e1dac3f4912fd824239e0c9c3681)): ?>
<?php $component = $__componentOriginale556e1dac3f4912fd824239e0c9c3681; ?>
<?php unset($__componentOriginale556e1dac3f4912fd824239e0c9c3681); ?>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/sidebar/ads-sidebar.blade.php ENDPATH**/ ?>