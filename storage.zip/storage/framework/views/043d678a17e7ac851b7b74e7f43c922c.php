<?php $postHelper = app('App\Helpers\PostHelper'); ?>
<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $themeHelper = app('App\Helpers\ThemeHelper'); ?>
<?php $posts->each(function ($posts) {$posts->load('categories'); }); ?>

<?php if($count >=4): ?>
<section class="best-of-the-week">
    <div class="container">
        <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
        <h1>
            <div class="text">
                <?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?>

            </div>
            <div class="carousel-nav" id="best-of-the-week-nav">
                <div class="prev">
                    <i class="arrow-left"></i>
                </div>
                <div class="next">
                    <i class="arrow-right"></i>
                </div>
            </div>
        </h1>
        <?php endif; ?>
        <div class="owl-carousel owl-theme carousel-1" data-autoplay="<?php echo e($autoPlay); ?>">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="article">
                    <div class="inner">
                        <figure>
                            <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                <img src="<?php echo e($postHelper::showThumbnail($post)); ?>" alt="<?php echo e($post->post_image); ?>" alt="<?php echo e($post->post_image); ?>">
                            </a>
                        </figure>
                        <div class="padding">
                            <div class="detail">
                                <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                                <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                    <div class="category">
                                        <a href="<?php echo e($termHelper::categoryUrl($post)); ?>">
                                            <?php echo e($termHelper::categoryName($post)); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <h2><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a></h2>
                            <p><?php echo \Str::limit(strip_tags($post->post_content), 100); ?></p>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/bottom-post.blade.php ENDPATH**/ ?>