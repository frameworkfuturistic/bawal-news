

<?php $__env->startSection('title', __('Web Information')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('title.web_config')).'','currentActive' => ''.e(__('title.web_config')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.Select2', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                <form id="form-web-config" action="<?php echo e(route('settings.webconfig.update')); ?>" method="POST" role="form">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="web_config">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('form.measurement_id')); ?></label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fab fa-google"></i></span>
                                    </div>
                                    <input type="text" name="measurement_id" class="form-control" placeholder="<?php echo e(__('form.placeholder_measurement_id')); ?>" value="<?php echo e(config('settings.measurement_id')); ?>">
                                    <div class="msg-googleanalyticsid"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for=""><?php echo e(__('form.publisher_id')); ?></label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-bullhorn"></i></span>
                                    </div>
                                    <input type="text" name="publisher_id" class="form-control" placeholder="<?php echo e(__('form.placeholder_publisher_id')); ?>" value="<?php echo e(config('settings.publisher_id')); ?>">
                                    <div class="msg-publisherid"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for=""><?php echo e(__('form.disqus_shortname')); ?></label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-comments"></i></span>
                                    </div>
                                    <input type="text" name="disqus_shortname" class="form-control" placeholder="<?php echo e(__('form.placeholder_disqus_shortname')); ?>" value="<?php echo e(config('settings.disqus_shortname')); ?>">
                                    <div class="msg-disqusshortname"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('form.property_id')); ?></label>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fas fa-chart-line"></i></span>
                                    </div>
                                    <input type="text" name="property_id" class="form-control" placeholder="<?php echo e(__('form.placeholder_property_id')); ?>" value="<?php echo e($propertyId); ?>">
                                    <div class="msg-propertyid"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label><?php echo e(__('form.credentials_file')); ?></label><br>
                                <div class="input-group">
                                    <div class="custom-file">
                                        <input type="file" name="credentials_file" class="custom-file-input" id="credentialFile" value="<?php echo e(config('settings.credentials_file')); ?>">
                                        <label class="custom-file-label" for="credentialFile"><?php echo e(__('form.placeholder_credentials_file')); ?></label>
                                    </div>
                                </div>
                                <p>
                                    <small>
                                        <?php echo e(__('form.help_credentials_file')); ?><br>
                                    </small>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-12">
                            <button id="submit-web-config" type="submit" class="btn btn-info float-right"><?php echo e(__('button.save')); ?></button>
                        </div>
                    </div>
                </form>
                <hr>
                <div class="row mt-3">
                    <div class="form-group col-lg-12">
                        <label><?php echo e(__('form.display_language_options')); ?></label>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="maintenance"
                                class="custom-control-input" data-id="" id="switchDisplayLanguage" <?php echo e($showLanguage); ?>>
                            <label class="custom-control-label" for="switchDisplayLanguage">
                                <?php echo e(__('form.label_display_language_options')); ?>

                            </label>
                        </div>
                    </div>
                    <div class="form-group col-lg-12">
                        <label for="default_language"><?php echo e(__('form.default_language')); ?></label>
                        <select id="default_language" name="default_language" class="form-control">
                            <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $languageCode => $languageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($languageCode == config('settings.default_language')): ?>
                                    <option value="<?php echo e($languageCode); ?>" selected="selected"><?php echo e($languageName); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($languageCode); ?>"><?php echo e($languageName); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small id="defaultlanguageHelp" class="form-text text-muted">
                            <?php echo e(__('form.help_default_language')); ?>

                        </small>
                    </div>
                </div>
                <hr>
                <div class="row mt-3">
                    <div class="form-group col-lg-12">
                        <label><?php echo e(__('form.comments_require_approval')); ?></label>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="comment_approval"
                                class="custom-control-input" id="commentReqApproval" <?php echo e($commentApproval); ?>>
                            <label class="custom-control-label" for="commentReqApproval">
                                <?php echo e(__('form.label_comments_require_approval')); ?>

                            </label>
                        </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="number_nested_comments"><?php echo e(__('form.number_of_nested_comments')); ?></label>
                        <select id="number_nested_comments" name="number_nested_comments" class="form-control" style="width:auto;">
                            <?php $__currentLoopData = $numberNestedComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($no == config('settings.number_nested_comments')): ?>
                                    <option value="<?php echo e($no); ?>" selected="selected"><?php echo e($no); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($no); ?>"><?php echo e($no); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-lg-12">
                        <label><?php echo e(__('form.send_comment_reply_email')); ?></label>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="send_comment_reply_email"
                                class="custom-control-input" id="sendCommentReplyEmail" <?php echo e($sendCommentReplyEmail); ?>>
                            <label class="custom-control-label" for="sendCommentReplyEmail">
                                <?php echo e(__('form.label_send_comment_reply_email')); ?>

                            </label>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row mt-3">
                    <div class="form-group col-lg-12">
                        <label><?php echo e(__('form.maintenance_mode')); ?></label>
                        <div class="custom-control custom-switch">
                            <input type="checkbox" name="maintenance"
                                class="custom-control-input" data-id="" id="customSwitch1" <?php echo e($maintenance); ?>>
                            <label class="custom-control-label" for="customSwitch1">
                                <?php echo e(__('form.label_maintenance_mode')); ?>

                            </label>
                        </div>
                    </div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('register-users')): ?>
                        <div class="form-group col-lg-12">
                            <label><?php echo e(__('form.register_user')); ?></label>
                            <div class="custom-control custom-switch">
                                <input type="checkbox" name="maintenance" class="custom-control-input" data-id="" id="customSwitch2" <?php echo e($register); ?>>
                                <label class="custom-control-label" for="customSwitch2">
                                    <?php echo e(__('form.label_register_user')); ?>

                                </label>
                            </div>
                        </div>
                        <div class="form-group col-lg-12">
                            <label><?php echo e(__('form.email_verification')); ?></label>
                            <div class="custom-control custom-switch">
                                <input type="checkbox" name="email_verification" class="custom-control-input" data-id="" id="customSwitch3" <?php echo e($emailVerification); ?>>
                                <label class="custom-control-label" for="customSwitch3">
                                    <?php echo e(__('form.label_email_verification')); ?>

                                </label>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('admin.settings._style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._csrf-token', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.languages._languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        // SET DISPLAY LANGUAGE OPTIONS
        $(document).on("change", "#switchDisplayLanguage", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/switch-display-language",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else if(data.success){
                        toastr.success(data.success);
                    }else{
                        toastr.error(data.abort);
                    }
                }
            })
        });

        // SET DEFAULT LANGUAGE
        $(document).on("change", "#default_language", function(e) {
            e.preventDefault();
            let dataLangCode = $('select#default_language').find(':selected').val() //get code;
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/change-default-language",
                data: {
                    'code': dataLangCode
                },
                success: function(response) {
                    toastr.success(response.success);
                    $("#default_language").select2("val", "");
                }
            })
        });

        // SET COMMENTS REQUIRE APPROVAL
        $(document).on("change", "#commentReqApproval", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/change-comment-req-approval",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else {
                        toastr.success(data.success);
                    }
                }
            })
        });

        // SET NUMBER OF NESTED COMMENTS
        $(document).on("change", "#number_nested_comments", function(e) {
            e.preventDefault();
            let dataNumberNestedComments = $('select#number_nested_comments').find(':selected').val() //get code;
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/change-number-nested-comment",
                data: {
                    'number_nested_comments': dataNumberNestedComments
                },
                success: function(response) {
                    toastr.success(response.success);
                    $("#number_nested_comments").select2("val", "");
                }
            })
        });

        // SEND COMMENT REPLY TO EMAIL
        $(document).on("change", "#sendCommentReplyEmail", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/change-send-comment-reply-email",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else {
                        toastr.success(data.success);
                    }
                }
            })
        });

        // SET MAINTENANCE MODE
        $(document).on("change", "#customSwitch1", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/changeStatusMaintenance",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else {
                        toastr.success(data.success);
                    }
                }
            })
        });

        // SET REGISTER USER
        $(document).on("change", "#customSwitch2", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/changeRegisterMember",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else if(data.success){
                        toastr.success(data.success);
                    }else{
                        toastr.error(data.abort);
                    }
                }
            })
        });


        // SET EMAIL VERIFICATION
        $(document).on("change", "#customSwitch3", function(e) {
            let active = $(this).prop("checked") == true ? "y" : "n";
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/change-active-email-verification",
                data: {
                    "active": active
                },
                success: function(data) {
                    if(data.info) {
                        toastr.info(data.info);
                    } else if(data.success){
                        toastr.success(data.success);
                    }else{
                        toastr.error(data.abort);
                    }
                }
            })
        });

        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/settings/web-config.blade.php ENDPATH**/ ?>