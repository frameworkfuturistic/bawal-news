

<?php $__env->startSection('title', __('title.web_information')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('title.web_information')).'','currentActive' => ''.e(__('title.web_information')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.Codemirror', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form id="form-web-information" action="<?php echo e(route('settings.webinfo.update')); ?>" method="POST" role="form">
                        <?php echo method_field('PATCH'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="company_name"><?php echo e(__('form.company_name')); ?></label>
                                    <input id="company_name" type="text" name="company_name" class="form-control" placeholder="<?php echo e(__('form.placeholder_company_name')); ?>" value="<?php echo e(config('settings.company_name')); ?>">
                                    <div class="msg-company_name"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="site_name"><?php echo e(__('form.web_name')); ?></label>
                                    <input id="site_name" type="text" name="site_name" class="form-control" placeholder="<?php echo e(__('form.placeholder_web_name')); ?>" value="<?php echo e(config('settings.site_name')); ?>">
                                    <div class="msg-site_name"></div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="site_url"><?php echo e(__('form.web_url')); ?></label>
                                    <input id="site_url" type="text" name="site_url" class="form-control" placeholder="<?php echo e(__('form.placeholder_web_url')); ?>" value="<?php echo e(config('settings.site_url')); ?>">
                                    <div class="msg-site_url"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="site_description"><?php echo e(__('form.web_description')); ?></label>
                                    <textarea id="site_description" name="site_description" class="form-control" rows="3" placeholder="<?php echo e(__('form.placeholder_web_description')); ?>.."><?php echo e(config('settings.site_description')); ?></textarea>
                                    <div class="msg-site_description"></div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="meta_keyword"><?php echo e(__('form.web_keyword')); ?></label>
                                    <textarea id="meta_keyword" name="meta_keyword" class="form-control" rows="3" placeholder="<?php echo e(__('form.placeholder_web_keyword')); ?>"><?php echo e(config('settings.meta_keyword')); ?></textarea>
                                    <div class="msg-meta_keyword"></div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="credit_footer"><?php echo e(__('form.credit_footer')); ?></label>
                                    <textarea class="form-control" name="credit_footer" id="credit_footer" rows="3"><?php echo e($creditFooter); ?></textarea>
                                    <div class="msg-credit_footer"></div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button id="submit" type="submit" class="btn btn-info float-right"><?php echo e(__('button.save')); ?></button>
                        </div>
                    </form>
                </div>
                <!-- /.card -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('admin.settings._style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._csrf-token', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.languages._languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        "use strict";
        
        let editor = CodeMirror.fromTextArea(document.getElementById("credit_footer"), {
            mode: "htmlmixed",
            styleActiveLine: true,
            lineNumbers: true,
            lineWrapping: true,
            matchBrackets: true
        });
        editor.setSize(null, 100);
        editor.on('change', (editor) => {
            const text = editor.doc.getValue()
            $('#credit_footer').html(text);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
























<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/settings/web-info.blade.php ENDPATH**/ ?>