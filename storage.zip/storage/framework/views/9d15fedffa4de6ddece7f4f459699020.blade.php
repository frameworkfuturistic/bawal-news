<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
@props(['page','layout','widgetName','widgetData','localeId'])
<x-posts :page="$page" :layout="$layout" :widgetName="$widgetName" :widgetData="$widgetData" :localeId="$localeId" {{ $attributes }}>

{{ $slot ?? "" }}
</x-posts>