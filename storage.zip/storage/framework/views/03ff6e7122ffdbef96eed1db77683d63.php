<?php $postHelper = app('App\Helpers\PostHelper'); ?>
<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $posts->each(function ($posts) {$posts->load('categories'); }); ?>

<?php if($widgetData['layout_type'] == 'list-post-with-link'): ?>
    <aside>
        <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
        <h1 class="aside-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?> 
            <a href="<?php echo e(route('article.popular')); ?>" class="all"><?php echo e(__('Laramagz::magz.see_all')); ?> <i class="arrow-right"></i></a>
        </h1>
        <?php endif; ?>
        <div class="aside-body">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="article-mini">
                    <div class="inner">
                        <figure>
                            <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                <img src="<?php echo e($postHelper::showThumbnail($post, 80)); ?>" alt="<?php echo e($post->post_image); ?>">
                            </a>
                        </figure>
                        <div class="padding">
                            <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a>
                            </h1>
                            <div class="detail">
                                <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                    <div class="category">
                                        <a href="<?php echo e($termHelper::categoryUrl($post)); ?>">
                                             <?php echo e($post->categories->first()->name); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </aside>
<?php elseif($widgetData['layout_type'] == 'first-large-thumb'): ?>
    <aside>
        <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
        <h1 class="aside-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
        <?php endif; ?>
        <div class="aside-body">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->first): ?>
                    <article class="article-fw">
                        <div class="inner">
                            <figure>
                                <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                    <img src="<?php echo e($postHelper::showThumbnail($post, 356)); ?>" alt="<?php echo e($post->post_image); ?>">
                                </a>
                            </figure>
                            <div class="details">
                                <div class="detail">
                                    <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                                    <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                        <div class="category">
                                            <a href="<?php echo e(route('category.show', $post->terms()->category()->first()->slug)); ?>">
                                                 <?php echo e($post->categories->first()->name); ?>

                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a>
                                </h1>
                                <p><?php echo e(\Str::limit(strip_tags($post->post_content), 100)); ?></p>
                            </div>
                        </div>
                    </article>
                    <div class="line mt-1 mb-4"></div>
                <?php else: ?>
                    <article class="article-mini">
                        <div class="inner">
                            <figure>
                                <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                    <img src="<?php echo e($postHelper::showThumbnail($post, 80)); ?>" alt="<?php echo e($post->post_image); ?>">
                                </a>
                            </figure>
                            <div class="padding">
                                <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a>
                                </h1>
                                <div class="detail">
                                    <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                        <div class="category">
                                            <a href="<?php echo e(route('category.show', $post->categories->first()->slug)); ?>">
                                                 <?php echo e($post->categories->first()->name); ?>

                                            </a>
                                        </div>
                                    <?php endif; ?>
                                    <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </aside>
<?php else: ?>
    <aside>
        <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
        <h1 class="aside-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
        <?php endif; ?>
        <div class="aside-body">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="article-mini">
                    <div class="inner">
                        <figure>
                            <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                <img src="<?php echo e($postHelper::showThumbnail($post, 80)); ?>" alt="<?php echo e($post->post_image); ?>">
                            </a>
                        </figure>
                        <div class="padding">
                            <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a>
                            </h1>
                            <div class="detail">
                                <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                                    <div class="category">
                                        <a href="<?php echo e(route('category.show', $post->terms()->category()->first()->slug)); ?>">
                                             <?php echo e($post->categories->first()->name); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>
                                <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                            </div>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </aside>

<?php endif; ?>

<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/sidebar/post-sidebar.blade.php ENDPATH**/ ?>