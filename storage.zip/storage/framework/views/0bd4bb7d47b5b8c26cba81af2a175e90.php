

<?php $__env->startSection('title', __('Web Contact')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
<?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('title.web_contact')).'','currentActive' => ''.e(__('title.web_contact')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.IconPicker', true); ?>
<?php $__env->startSection('plugins.ColorPicker', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header p-2">
                <ul id="navTab" class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#address" data-toggle="tab"><?php echo e(__('Contact Address')); ?></a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#links" data-toggle="tab"><?php echo e(__('Contact Links')); ?></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="active tab-pane" id="address">
                        <form action="<?php echo e(route('settings.webcontact.update')); ?>" method="POST" role="form">
                            <?php echo method_field('PATCH'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <label for="street"><?php echo e(__('form.address_street')); ?></label>
                                        <input id="street" type="text" name="street" class="form-control" placeholder="<?php echo e(__('form.placeholder_address_street')); ?>" value="<?php echo e(config('settings.street')); ?>">
                                        <div class="msg-street"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="city"><?php echo e(__('form.city')); ?></label>
                                        <input id="city" type="text" name="city" class="form-control" placeholder="<?php echo e(__('form.placeholder_city')); ?>" value="<?php echo e(config('settings.city')); ?>">
                                        <div class="msg-city"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="postal_code"><?php echo e(__('form.postal_code')); ?></label>
                                        <input id="postal_code" type="text" name="postal_code" class="form-control" placeholder="<?php echo e(__('form.placeholder_postal_code')); ?>" value="<?php echo e(config('settings.postal_code')); ?>">
                                        <div class="msg-postal_code"></div>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="state"><?php echo e(__('form.state')); ?></label>
                                        <input id="state" type="text" name="state" class="form-control" placeholder="<?php echo e(__('form.placeholder_state')); ?>" value="<?php echo e(config('settings.state')); ?>">
                                        <div class="msg-state"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="country"><?php echo e(__('form.country')); ?></label>
                                        <input id="country" type="text" name="country" class="form-control" placeholder="<?php echo e(__('form.placeholder_country')); ?>" value="<?php echo e(config('settings.country')); ?>">
                                        <div class="msg-country"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="siteemail"><?php echo e(__('form.email')); ?></label>
                                        <input id="siteemail" type="email" name="site_email" class="form-control" placeholder="<?php echo e(__('form.placeholder_email')); ?>" value="<?php echo e(config('settings.site_email')); ?>">
                                        <div class="msg-siteemail"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="sitephone"><?php echo e(__('form.phone')); ?></label>
                                        <input id="sitephone" type="text" name="site_phone" class="form-control" placeholder="<?php echo e(__('form.placeholder_phone')); ?>" value="<?php echo e(config('settings.site_phone')); ?>">
                                        <div class="msg-sitephone"></div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <ul class="list-flags list-inline float-right ml-2 mb-0">
                                        <?php $__currentLoopData = LocalizationHelper::getListFlags(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php    
                                            $active = ($language->id == Auth::user()->language) ? 'active' : '';
                                            ?>
                                            <li class="list-inline-item mr-0 <?php echo e($active); ?>" data-lang="<?php echo e($language->language); ?>"><i class="flag-icon flag-icon-<?php echo e(Str::lower($language->country_code)); ?>"></i></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="form-group">
                                        <label for="contactdescription"><?php echo e(__('form.contact_description')); ?></label>
                                        <div id="contact_desc_el" class="form-group">
                                            <?php 
                                                $data = json_decode(config('settings.contact_description'), true)
                                            ?>
                                            <?php if($data): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $txt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $hidden = (LocalizationHelper::getLangCodeById(Auth::user()->language) != $lang) ? 'hidden' : ''; ?>
                                                    <textarea id="contactdescription" name="contact_description[<?php echo e($lang); ?>]"
                                                class="form-control contact_description input-contact-desc-<?php echo e($lang); ?>" rows="5" placeholder="<?php echo e(__('form.placeholder_contact_description')); ?>" <?php echo e($hidden); ?>><?php echo nl2br($txt); ?></textarea>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>  
                                                <textarea id="contactdescription" name="contact_description[<?php echo e($currentLanguage->language); ?>]" class="form-control contact_description input-contact-desc-<?php echo e($currentLanguage->language); ?>" rows="5" placeholder="<?php echo e(__('form.placeholder_contact_description')); ?>"></textarea>
                                            <?php endif; ?>
                                        </div>
                                        <div class="msg-contactdescription"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button id="submit-web-contact" type="submit" class="btn btn-info float-right"><?php echo e(__('button.save')); ?></button>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane" id="links">
                        <div class="row">
                        <div class="col-lg-12">
                            <div class="form-group">
                                <label for="socialmedia"><?php echo e(__('form.links')); ?></label>
                                <p><?php echo e(__('form.links_info')); ?></p>
                                <button type="button" class="btn btn-light btn-sm" id="addLink">+ ADD LINK</button>
                            </div>
                        </div>
                        </div>
                        <div class="row links">
                            <?php if($links): ?>
                                <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-lg-6 mb-3" id="link<?php echo e($link->id); ?>">
                                        <div class="form-group">
                                            <label><?php echo e($link->name); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i class="<?php echo e($link->icon); ?>"></i></span>
                                                </div>
                                                <input type="text" name="url" class="bg-link-input form-control" placeholder="" value="<?php echo e($link->url); ?>" title="<?php echo e($link->url); ?>" readonly>
                                                <div class="input-group-append" onclick="removeInput('<?php echo e($link->id); ?>')" style="cursor:pointer">
                                                    <span class="input-group-text"><i class="fas fa-times"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<?php echo $__env->make('admin.settings._link-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('admin.settings._style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._csrf-token', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.languages._languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(() => {
            let url = location.href.replace(/\/$/, "");

            if (location.hash) {
                const hash = url.split("#");
                $('#navTab a[href="#' + hash[1] + '"]').tab("show");
                url = location.href.replace(/\/#/, "#");
                history.replaceState(null, null, url);
                setTimeout(() => {
                    $(window).scrollTop(0);
                }, 400);
            }

            $('a[data-toggle="tab"]').on("click", function() {
                let newUrl;
                const hash = $(this).attr("href");
                newUrl = url.split("#")[0] + hash;
                newUrl += "/";
                history.replaceState(null, null, newUrl);
            });
        });
    </script>
    <script>
        "use strict";

        // SELECT FLAG **^
        $(document).on("click", ".list-flags li", function(e) {
            if (!$(this).hasClass('active')) {
                $('.list-flags li.active').removeClass('active');
                $(this).addClass('active');
            }
        });
        // END SELECT FLAG....................................................

        // SET CONTACT DESCRIPTION ***
        $(document).on("click", ".list-flags li.list-inline-item", function(e) {
            let lang = $(this).data('lang');

            if (!$(this).hasClass('input-contact-desc-' + lang)) {
                $('#contact_desc_el textarea').attr('hidden', true);
            }

            if ($('#contact_desc_el textarea').hasClass('input-contact-desc-' + lang)) {
                $('#contact_desc_el textarea.input-contact-desc-' + lang).removeAttr('hidden');
            } else {
                $('#contact_desc_el').append('<textarea id="contactdescription" name="contact_description[' + lang + ']" class="form-control contact_description input-contact-desc-' + lang + '" rows="3"></textarea>');
            }
        });
        // SET CONTACT DESCRIPTION.......................................

        $(function () {
            $('.icp-auto').iconpicker();
            $('#cp2').colorpicker();
        });

        // SHOWING MODAL
        $('#addLink').on('click', function(){
            $('#add-link-modal').modal('show');
        });

        // RESET FORM MODAL
        $('#add-link-modal').on('hidden.bs.modal', function () {
            $('#linkForm')[0].reset();

            $('#link-label, #link-url').removeClass('is-invalid').next('.invalid-feedback').html('');
            $('#link-icon').removeClass('is-invalid').closest('.iconpicker-container').removeClass('is-invalid').next('.invalid-feedback').html('');
            $('#link-color').removeClass('is-invalid').closest('#cp2').removeClass('is-invalid').next('.invalid-feedback').html('');
        });

        // SUBMIT FORM MODAL
        $('#submitAddLink').on('click', function(){
            if ($('#link-label').val() == '') {
                $('#link-label').addClass('is-invalid').next('.invalid-feedback').html("<?php echo e(__('validation.required', ['attribute'=>'Label'])); ?>");
            } else {
                $('#link-label').removeClass('is-invalid').next('.invalid-feedback').html('');
            }

            if ($('#link-url').val() == '') {
                $('#link-url').addClass('is-invalid').next('.invalid-feedback').html("<?php echo e(__('validation.required', ['attribute'=>'URL'])); ?>");
            } else {
                $('#link-url').removeClass('is-invalid').next('.invalid-feedback').html('');
            }

            if ($('#link-icon').val() == '') {
                $('#link-icon').addClass('is-invalid').closest('.iconpicker-container').addClass('is-invalid').next('.invalid-feedback').html("<?php echo e(__('validation.required', ['attribute'=>'Icon'])); ?>");
            } else {
                $('#link-icon').removeClass('is-invalid').closest('.iconpicker-container').removeClass('is-invalid').next('.invalid-feedback').html('');
            }

            if ($('#link-color').val() == '') {
                $('#link-color').addClass('is-invalid').closest('#cp2').addClass('is-invalid').next('.invalid-feedback').html("<?php echo e(__('validation.required', ['attribute'=>'Color'])); ?>");
            } else {
                $('#link-color').removeClass('is-invalid').closest('#cp2').removeClass('is-invalid').next('.invalid-feedback').html('');
            }

            let data = {
                "name": $('#link-label').val(),
                "url": $('#link-url').val(),
                "icon": $('#link-icon').val(),
                "color": $('#link-color').val(),
            }

            $.ajax({
                type: 'POST',
                url: '/admin/createdatalink',
                data: data,
                dataType: 'json',
                success: function(data) {
                    let linkData = data.data;

                    if (data.errors) {
                        $.each(data.errors, function (i, j) {
                            if (i == 'name') {
                                $("#link-label").addClass("is-invalid").next('.invalid-feedback').html(j);
                            }

                            if (i == 'url') {
                                $("#link-url").addClass("is-invalid").next('.invalid-feedback').html(j);
                            }

                            if (i == 'icon') {
                                $("#link-icon").addClass("is-invalid").next('.invalid-feedback').html(j);
                            }

                            if (i == 'color') {
                                $("#link-color").addClass("is-invalid").next('.invalid-feedback').html(j);
                            }
                        });
                    } else {
                        $('#add-link-modal').modal('hide');

                        $('#link-label, #add-link-modal #link-url').val('');
                        $('#link-icon').val('fas fa-link');
                        $('#link-color').val('#666666');

                        if (data.success) {
                            toastr.success(data.success);
                            let itemHtml = "";
                            linkData.forEach((item) => {
                                itemHtml +=
                                    `<div class="col-lg-6 mb-3" id="link${item.id}">
                                        <div class="form-group">
                                            <label>${item.name}</label>
                                            <div class="input-group">
                                                <input type="hidden" name="id" value="${item.id}">
                                                <div class="input-group-prepend"><span class="input-group-text"> <i class="${item.icon}"></i></span></div>
                                                <input type="text" name="link" class="bg-link-input form-control" placeholder="http://www.example.com" value="${item.url}" title="${item.url}" readonly>
                                                <div class="input-group-append" onclick="removeInput(${item.id})" style="cursor:pointer">
                                                    <span class="input-group-text"><i class="fas fa-times"></i></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>`;
                            });

                            $(".links").html(itemHtml);
                        } else {
                            toastr.error("<?php echo e(__('message.failed_to_save')); ?>");
                        }
                    } 
                }
            });
        });

        // REMOVE LINK
        function removeInput(id) {
            $.ajax({
                url: "/admin/links/"+id+"/site",
                type: 'DELETE',
                data: {
                    "id": id
                },
                success: function (response){
                    document.getElementById("link" + id).remove();
                    notification(response);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/settings/web-contact.blade.php ENDPATH**/ ?>