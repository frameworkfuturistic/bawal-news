<?php ($package='env-editor'); ?>
<?php ($translatePrefix='env-editor::env-editor.'); ?>



<?php $__env->startSection('title', __('Env-editor')); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('Env-editor')).'','currentActive' => ''.e(__('Env-editor')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js_pre'); ?>
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Axios', true); ?>
<?php $__env->startSection('plugins.Flag', true); ?>

<?php $__env->startSection('content'); ?>
    <div id="env-editor">
        <div id="env-alerts"></div>

        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#current-env" role="tab"><?php echo e(__($translatePrefix.'views.tabTitles.currentEnv')); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#backup-env" role="tab"><?php echo e(__($translatePrefix.'views.tabTitles.backup')); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#upload-env" role="tab"><?php echo e(__($translatePrefix.'views.tabTitles.upload')); ?></a>
            </li>
            <li class="nav-item ml-auto">
                <env-editor-config-actions></env-editor-config-actions>
            </li>
        </ul>

        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active p-3" id="current-env" role="tabpanel" aria-labelledby="nav-home-tab">
                <env-main-tab></env-main-tab>
            </div>
            <div class="tab-pane fade p-3" id="backup-env" role="tabpanel" aria-labelledby="nav-profile-tab">
                <env-editor-backups></env-editor-backups>
            </div>
            <div class="tab-pane fade p-3" id="upload-env" role="tabpanel" aria-labelledby="nav-contact-tab">
                <env-file-upload></env-file-upload>
            </div>
        </div>

        <env-keys-modal ref="keysModal"></env-keys-modal>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('env-editor::components._itemModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('env-editor::components._currentEnv', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('env-editor::components._upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('env-editor::components._backup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('env-editor::components._configActions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .content-wrapper {
            min-height: 100%;
            height: auto !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="<?php echo e(asset('vendor/vue/vue.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
<script>
    window.envEventBus = new Vue();
    const envAlert = ($type, $text) => {
        let alert =
            '<div id="__id__" class="alert alert-__type__ alert-dismissible fade show" role="alert">' +
            '  <div>__text__</div>' +
            '  <button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
            '    <span aria-hidden="true">&times;</span>' +
            '  </button>' +
            '</div>';
        let $id = 'env-alert_' + Date.now();
        let $html = alert.replace('__type__', $type).replace('__text__', $text).replace('__id__', $id);
        $('#env-alerts').append($html);
        setTimeout(() => {
            $('#' + $id).alert('close')
        }, 3000)

    };

    const dotEnv = new Vue({
        el: '#env-editor',
        components: {
            'env-main-tab': itemsWrapper,
            'env-keys-modal': itemsModal,
            'env-file-upload': fileUpload,
            'env-editor-backups': backUps,
            'env-editor-config-actions': configActions
        }
    })
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(config("$package.layout"), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/vendor/env-editor/index.blade.php ENDPATH**/ ?>