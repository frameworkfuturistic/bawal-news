<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>" data-bs-theme="light">
	<head>
        <?php echo $__env->make('frontend.magz.inc._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</head>

	<body class="skin-magz">
        <!-- Header -->
		<header class="primary" style="background-color: #104486">
            <?php echo $__env->make('frontend.magz.template-parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</header>

        <!-- Content -->
        <?php echo $__env->yieldContent('content'); ?>

		<!-- Start footer -->
		<footer class="footer <?php if(!$footerActive): ?> pt-0 <?php endif; ?>">
           <?php echo $__env->make('frontend.magz.template-parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		</footer>
		<!-- End Footer -->

		<!-- JS -->
        <?php echo $__env->make('frontend.magz.inc._scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</body>
</html>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/index.blade.php ENDPATH**/ ?>