<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="index, follow">
<meta name="author" content="<?php echo e(config('settings.company_name')); ?>">
<meta name="theme-color" content="#ffffff">
<meta name="color-scheme" content="light">
<?php echo SEO::generate(); ?>

<?php if(empty(config('settings.favicon'))): ?>
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('favicons/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('favicons/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('favicons/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('favicons/site.webmanifest')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicons/favicon.ico')); ?>" />
    <meta name="msapplication-TileColor" content="#ffffff">
<?php else: ?>
    <link rel="icon" sizes="32x32" href="<?php echo e(\App\Helpers\ImageHelper::webIcon()); ?>">
<?php endif; ?>
<meta name="google-site-verification" content="<?php echo e(config('settings.google_site_verification')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<link href="<?php echo e(asset('themes/magz/scripts/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themes/magz/scripts/owlcarousel/dist/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themes/magz/scripts/owlcarousel/dist/assets/owl.theme.default.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themes/magz/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('themes/magz/css/darkmode.css')); ?>" rel="stylesheet">
<?php if(LaravelLocalization::getCurrentLocaleDirection() == 'rtl'): ?>
<link href="<?php echo e(asset('themes/magz/css/rtl.css')); ?>" rel="stylesheet">
<?php endif; ?>
<link href="<?php echo e(asset('vendor/flag-icons/css/flag-icons.min.css')); ?>" rel="stylesheet">

<?php echo $__env->yieldPushContent('styles'); ?>

<?php if(config('settings.publisher_id')): ?>
    <!-- Google Adsense -->
    <script data-ad-client="<?php echo e(config('settings.publisher_id')); ?>" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<?php endif; ?>

<?php if(config('settings.measurement_id')): ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(config('settings.measurement_id')); ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', "<?php echo e(config('settings.measurement_id')); ?>");
    </script>
<?php endif; ?>

<!-- Mailchimp -->
<script id="mcjs">
    ! function(c, h, i, m, p) {
        m = c.createElement(h), p = c.getElementsByTagName(h)[0], m.async = 1, m.src = i, p.parentNode.insertBefore(m, p)
    }(document, "script", "https://chimpstatic.com/mcjs-connected/js/users/dce4ca90b74e9fafbfb2697a6/b08078aa3fbf02461cb5d711e.js");
</script>

<?php echo $__env->yieldPushContent('scripts_head'); ?>

<?php echo $__env->make('frontend.magz.inc._theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/inc/_head.blade.php ENDPATH**/ ?>