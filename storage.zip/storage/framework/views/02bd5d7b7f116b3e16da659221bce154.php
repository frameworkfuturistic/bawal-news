<li class="nav-item adminlte-language-widget dropdown">
    <a class="nav-link" data-toggle="dropdown" href="javascript:;" aria-expanded="false">
        <span class="d-none d-sm-inline"><i class="flag-icon <?php echo e($flagIcon); ?>"></i> <?php echo e($languageName); ?></span>
        <span class="d-blok d-sm-none text-uppercase"><i class="flag-icon <?php echo e($flagIcon); ?>"></i></span>
    </a>
    <div class="dropdown-menu dropdown-menu-right p-0">
        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($language->name != $languageName): ?>
                <a href="javascript:;" class="dropdown-item setting-language" data-id="<?php echo e($language->id); ?>">
                    <i class="flag-icon flag-icon-<?php echo e(Str::lower($language->country_code)); ?> mr-2"></i>
                    <?php echo e($language->name); ?>

                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</li>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/admin/navbar-language-widget.blade.php ENDPATH**/ ?>