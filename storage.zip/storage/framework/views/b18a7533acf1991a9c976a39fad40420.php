<?php if($layout == 'sidebar'): ?>
<aside id="sponsored">
    <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
    <h1 class="aside-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
    <?php endif; ?>
    <div class="aside-body">
        <figure class="ads">
            <?php if($widgetData['ad_url']): ?>
            <a href="<?php echo e($widgetData['ad_url']); ?>" target="_blank" aria-label="sidebar-banner-ads">
                <img src="<?php echo e($image); ?>" class="img-fluid" alt="Sidebar Banner Ads" width="350" height="300">
            </a>
            <?php else: ?>
                <img src="<?php echo e($image); ?>" class="img-fluid" alt="Sidebar Banner Ads" width="350" height="300">
            <?php endif; ?>
        </figure>
    </div>
</aside>
<?php else: ?>
<div class="banner">
    <?php if($widgetData['ad_url']): ?>
    <a href="<?php echo e($widgetData['ad_url']); ?>" target="_blank" aria-label="banner-ads">
        <img src="<?php echo e($image); ?>" alt="Banner Ads" width="750" height="80">
    </a>
    <?php else: ?>
        <img src="<?php echo e($image); ?>" alt="Banner Ads" width="750" height="80">
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/ads/image.blade.php ENDPATH**/ ?>