

<?php $__env->startSection('title', __('Web Contact')); ?>

<?php $__env->startSection('content_top_nav_right'); ?>
    <?php if (isset($component)) { $__componentOriginal5586259e5281f9ea17d8c92512ac75ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab = $attributes; } ?>
<?php $component = App\View\Components\Admin\NavbarLanguageWidget::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar-language-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\NavbarLanguageWidget::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $attributes = $__attributesOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__attributesOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab)): ?>
<?php $component = $__componentOriginal5586259e5281f9ea17d8c92512ac75ab; ?>
<?php unset($__componentOriginal5586259e5281f9ea17d8c92512ac75ab); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
    <?php if (isset($component)) { $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc = $attributes; } ?>
<?php $component = App\View\Components\Admin\Breadcrumbs::resolve(['title' => ''.e(__('title.web_permalinks')).'','currentActive' => ''.e(__('title.web_permalinks')).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('breadcrumbs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Admin\Breadcrumbs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $attributes = $__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__attributesOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc)): ?>
<?php $component = $__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc; ?>
<?php unset($__componentOriginaldd2a112a21f02a8b48e1f90fea4429dc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Flag', true); ?>
<?php $__env->startSection('plugins.Select2', true); ?>
<?php $__env->startSection('plugins.Pace', true); ?>
<?php $__env->startSection('plugins.Toastr', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.IcheckBootstrap', true); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <form id="form-web-permalinks" action="<?php echo e(route('settings.update')); ?>" method="POST" role="form">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <h5><?php echo e(__('form.post_permalinks')); ?></h5>
                    <hr>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="postname" name="permalink_type" value="post_name" <?php echo e(config('settings.permalink') === 'post_name' ? 'checked' : ''); ?>>
                            <label for="postname">
                                <?php echo e(__('form.post_name')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/sample-post</code>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="dayandname" name="permalink_type" value="%year%/%month%/%day%" <?php echo e(config('settings.permalink') === '%year%/%month%/%day%' ? 'checked' : ''); ?>>
                            <label for="dayandname">
                                <?php echo e(__('form.day_and_name')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/<?php echo e(now()->year); ?>/<?php echo e(now()->month); ?>/<?php echo e(now()->day); ?>/sample-post</code>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="monthandname" name="permalink_type" value="%year%/%month%" <?php echo e(config('settings.permalink') === '%year%/%month%' ? 'checked' : ''); ?>>
                            <label for="monthandname">
                                <?php echo e(__('form.month_and_name')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/<?php echo e(now()->year); ?>/<?php echo e(now()->month); ?>/sample-post</code>
                        </div>
                    </div>
                    <div class="form-group clearfix">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="custom" name="permalink_type" value="custom" <?php echo e(config('settings.permalink_type') === 'custom' ? 'checked' : ''); ?>>
                            <label for="custom" style="line-height: inherit">
                                <?php echo e(__('form.custom')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/</code>
                            <?php if(config('settings.permalink_type') == 'custom'): ?>
                                <input type="text" class="form-control-custom" value="<?php echo e(config('settings.permalink')); ?>" name="custom_input">
                            <?php else: ?>
                                <input type="text" class="form-control-custom" value="<?php echo e(config('settings.permalink_old_custom')); ?>" name="custom_input">
                            <?php endif; ?>

                            <code>/sample-post</code>
                        </div>
                    </div>

                    <div class="row mt-3">&nbsp;</div>

                    <h5><?php echo e(__('form.page_permalinks')); ?></h5>
                    <hr>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="pagename" name="page_permalink_type" value="page_name" <?php echo e(config('settings.page_permalink_type') === 'page_name' ? 'checked' : ''); ?>>
                            <label for="pagename">
                                <?php echo e(__('form.page_name')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/sample-page</code>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="withprefix" name="page_permalink_type" value="with_prefix" <?php echo e(config('settings.page_permalink_type') === 'with_prefix' ? 'checked' : ''); ?>>
                            <label for="withprefix">
                                <?php echo e(__('form.with_prefix')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/page/sample-page</code> 
                        </div>
                    </div>

                    <div class="row mt-3">&nbsp;</div>
                    <h5><?php echo e(__('form.category_permalinks')); ?></h5>
                    <hr>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="categoryname" name="category_permalink_type" value="category_name" <?php echo e(config('settings.category_permalink_type') === 'category_name' ? 'checked' : ''); ?>>
                            <label for="categoryname">
                                <?php echo e(__('form.category_name')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/sample-category</code>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="icheck-primary d-inline">
                            <input type="radio" id="withprefixcategory" name="category_permalink_type" value="with_prefix_category" <?php echo e(config('settings.category_permalink_type') === 'with_prefix_category' ? 'checked' : ''); ?>>
                            <label for="withprefixcategory">
                                <?php echo e(__('form.with_prefix')); ?>

                            </label>
                            <code><?php echo e(url('/')); ?>/category/sample-category</code>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    <?php echo $__env->make('admin.settings._style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <?php echo $__env->make('layouts.partials._notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._switch_lang', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials._csrf-token', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.languages._languages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        "use strict";

        // SET PERMALINKS **
        function setConfig() {
            let obj = $(this),
            value = $(this).val(),
            key = $(this).attr('name');
            $(this).closest('.icheck-primary').append('<div class="spinner-grow spinner-grow-sm" role="status"><span class="sr-only">Loading...</span></div>');

            let data;
            if (value == 'custom') {
                data = {
                    "key": key,
                    "value": value,
                    "custom": $(this).closest('.icheck-primary').find('.form-control-custom').val()
                }
            } else {
                data = {
                    "key": key,
                    "value": value
                }
            }
            
            $.ajax({
                type: "PATCH",
                dataType: "json",
                url: "/admin/settings/set-config",
                data: data
            })
            .done(function(data) {
                obj.closest('.icheck-primary').children('div.spinner-grow').remove();

                if(data.info) {
                    toastr.info(data.info);
                } else if(data.success){
                    toastr.success(data.success);
                }else{
                    toastr.error(data.abort);
                }
            })
        }

        $(document).on("click", "input[name=page_permalink_type]", setConfig);
        $(document).on("click", "input[name=category_permalink_type]", setConfig);
        $(document).on("click", "input[name=permalink_type]", setConfig);

        $('.form-control-custom').blur(function (e) {
            const isPrefixCustom = $('#custom').is(':checked');

            if ( isPrefixCustom ) {
                let value = $('.form-control-custom').val(),
                data = {
                    "key": 'permalink',
                    "value": value
                }

                $('.form-control-custom').closest('.icheck-primary').append('<div class="spinner-grow spinner-grow-sm" role="status"><span class="sr-only">Loading...</span></div>');

                $.ajax({
                    type: "PATCH",
                    dataType: "json",
                    url: "/admin/settings/set-config",
                    data: data
                })
                .done(function(data) {
                    $('.form-control-custom').closest('.icheck-primary').children('div.spinner-grow').remove();

                    if(data.info) {
                        toastr.info(data.info);
                    } else if(data.success){
                        toastr.success(data.success);
                    }else{
                        toastr.error(data.abort);
                    }
                })
            }
        })
        // END SET PERMALINKS **
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('layouts.partials._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/admin/settings/web-permalinks.blade.php ENDPATH**/ ?>