<?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
<h1 class="block-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
<?php endif; ?>
<div class="block-body">
     <?php if($widgetData['description'] && Arr::exists($widgetData['description'], LaravelLocalization::getCurrentLocale())): ?>
     <p><?php echo e($widgetData['description'][LaravelLocalization::getCurrentLocale()]); ?></p>
     <?php endif; ?>
    <form class="newsletter">
        <div class="input-group">
            <span class="input-group-text" id="basic-addon1"><i class="fa-regular fa-envelope"></i></span>
            <input type="email" name="email" class="form-control email" placeholder="<?php echo e(__('Laramagz::magz.your_mail')); ?>" aria-label="email" aria-describedby="basic-addon1">
        </div>
        <div class="d-grid gap-2">
            <button class="btn btn-primary white"><?php echo e(__('Laramagz::magz.subscribe')); ?></button>
        </div>
    </form>
</div>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/footer/newsletter-footer.blade.php ENDPATH**/ ?>