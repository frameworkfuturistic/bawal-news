<ul class="footer-copyright list-inline d-inline-block mb-0">
    <li class="list-inline-item">
        <span class="d-none d-sm-inline"><?php echo e(__('Copyright')); ?></span>
        &copy; <?php echo e(\Carbon\Carbon::now()->format('Y')); ?>

    </li>
    <li class="list-inline-item">
        <a href="<?php echo e(config('settings.site_url')); ?>">
            <strong><?php echo e(config('settings.company_name')); ?></strong>
        </a>
    </li>
    <li class="list-inline-item">
        <span class="d-none d-sm-inline"> <?php echo e(__('All Rights Reserved')); ?></span>
    </li>
</ul>

<ul class="list-inline d-inline-block float-right mb-0">
    <li class="list-inline-item d-none d-sm-inline"><strong><?php echo e(__('Env')); ?></strong> <?php echo e(App::environment()); ?></li>
    <li class="list-inline-item">
        <strong class="d-none d-sm-inline"><?php echo e(__('Version')); ?></strong>
        <span class="d-blok d-sm-none">v</span><?php echo e(config('retenvi.version')); ?></li>
</ul>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/layouts/partials/_footer.blade.php ENDPATH**/ ?>