<?php $imageHelper = app('App\Helpers\ImageHelper'); ?>

<nav class="menu">
    <div class="container">
        <div class="brand">
            <a href="/">
                <img class="logo_dark" src="<?php echo e($imageHelper::webLogoLight()); ?>" alt="Web Logo">
                <img class="logo_light" src="<?php echo e($imageHelper::webLogoDark()); ?>" alt="Web Logo">
            </a>
        </div>
        <div class="mobile-toggle">
            <a href="#" data-toggle="menu" data-target="#menu-list"><i class="fa-solid fa-bars"></i></a>
        </div>
        <div class="mobile-toggle">
            <a href="#" data-toggle="sidebar" data-target="#sidebar"><i class="arrow-left"></i></a>
        </div>
        <div id="menu-list">
            <?php $menus = $menuHeader ?>
            <?php if($menus): ?>
                <ul class="nav-list">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="<?php if($menu['child']): ?>dropdown magz-dropdown <?php endif; ?>">
                            <a href="<?php echo e($menu['link']); ?>" title=""><?php echo e($menu['label']); ?> <?php if($menu['child']): ?><i class="arrow-right"></i><?php endif; ?></a>
                            <?php if($menu['child']): ?>
                                <?php echo $__env->make('frontend.magz.inc._child', ['childs'=>$menu['child']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <ul class="float-end">
                <?php if($displayLanguage == 'y'): ?>
                <li class="dropdown magz-dropdown">  
                    <a href="javascript:;"><span class="flag-icon flag-icon-<?php echo e(\App\Helpers\LocalizationHelper::getCurrentLocaleFlag(LaravelLocalization::getCurrentLocaleRegional())); ?> mr-1"></span> <span class="d-none d-sm-inline"><?php echo e(LaravelLocalization::getCurrentLocaleName()); ?></span></a>
                    <?php if(count($languages) > 1): ?>
                    <ul class="dropdown-menu">
                        <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($language->language != LaravelLocalization::getCurrentLocale()): ?>
                                <li>
                                    <a rel="alternate" hreflang="<?php echo e($language->language); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($language->language, null, [], true)); ?>">
                                        <span class="flag-icon flag-icon-<?php echo e(Str::lower($language->country_code)); ?> mr-1"></span>
                                        <?php echo e($language->name); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </li>
                <?php endif; ?>
                <li>
                    <a id="icon_system" onclick="toDarkMode()" title="Switch to dark mode" class="text-gray-500">
                        <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M12 2A10 10 0 0 0 2 12A10 10 0 0 0 12 22A10 10 0 0 0 22 12A10 10 0 0 0 12 2M12 4A8 8 0 0 1 20 12A8 8 0 0 1 12 20V4Z"></path>
                        </svg>
                    </a>
                    <a id="icon_sun" onclick="toSystemMode()" title="Switch to system theme">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-sun" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                            <circle cx="12" cy="12" r="4"></circle>
                            <path d="M3 12h1m8 -9v1m8 8h1m-9 8v1m-6.4 -15.4l.7 .7m12.1 -.7l-.7 .7m0 11.4l.7 .7m-12.1 -.7l-.7 .7"></path>
                        </svg>
                    </a>
                    <a id="icon_moon" onclick="toLightMode()" title="Switch to light mode">
                        <svg xmlns="http://www.w3.org/2000/svg" height="1.5em" viewBox="0 0 93.42 96.95"><style>svg{fill:#ffffff}</style><path d="M30.71,11.93A55.28,55.28,0,0,0,84.5,78.33a43.23,43.23,0,1,1-53.79-66.4M40.57,1.52A49.21,49.21,0,1,0,96.71,70.87,49.22,49.22,0,0,1,40.57,1.52Z" transform="translate(-3.29 -1.52)"/><polygon points="71.83 35.38 61.1 29.61 50.27 35.19 52.43 23.2 43.79 14.62 55.86 12.98 61.34 2.1 66.64 13.07 78.67 14.93 69.88 23.35 71.83 35.38"/><polygon points="85.12 51.08 82.75 55.59 85.13 60.1 80.11 59.24 76.55 62.9 75.82 57.85 71.25 55.6 75.81 53.34 76.54 48.3 80.1 51.95 85.12 51.08"/></svg>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/header/menu-header.blade.php ENDPATH**/ ?>