<?php if($active): ?>
    <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
    <h1 class="block-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
    <?php endif; ?>
    <div class="block-body">
        <?php if($widgetData['description'] && Arr::exists($widgetData['description'], LaravelLocalization::getCurrentLocale())): ?><p><?php echo e($widgetData['description'][LaravelLocalization::getCurrentLocale()]); ?></p><?php endif; ?>
        <ul class="social trp">
            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e($link->url); ?>" style="background-color: <?php echo e($link->color); ?>" aria-label="link-social-media">
                        <i class="<?php echo e($link->icon); ?>"></i>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/links.blade.php ENDPATH**/ ?>