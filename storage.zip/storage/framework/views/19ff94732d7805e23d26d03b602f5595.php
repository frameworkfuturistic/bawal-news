<?php $postHelper = app('App\Helpers\PostHelper'); ?>
<?php $videoHelper = app('App\Helpers\VideoHelper'); ?>
<?php $audioHelper = app('App\Helpers\AudioHelper'); ?>
<?php $themeHelper = app('App\Helpers\ThemeHelper'); ?>

<?php $__env->startSection('content'); ?>
<section class="category top" style="padding-top:370px">
    <div class="container-md">
        <div class="row">
            <?php if($sidebarPosition === "left" && $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="col-lg-8 text-left <?php if($sidebarActive === false): ?> offset-lg-2 <?php endif; ?>">
                <div class="row">
                    <?php if($category): ?>
                    <div class="col-lg-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/"><?php echo e(__('Laramagz::magz.home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e($category->name); ?></li>
                        </ol>
                        <h1 class="page-title"><?php echo e(__('Laramagz::magz.category')); ?>: <?php echo e($category->name); ?></h1>
                        <p class="page-subtitle"><?php echo e(__('Laramagz::magz.category_description')); ?>  <i><?php echo e($category->name); ?></i></p>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="line"></div>
                <div class="row">
                    <?php if($posts): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="col-lg-12 article-list">
                        <div class="inner">
                            <figure>
                                <a href="<?php echo e($postHelper->getUriPost($post)); ?>">
                                    <?php if($post->post_type == 'post' OR $post->post_type == 'page'): ?>
                                        <img src="<?php echo e($postHelper->showThumbnail($post, 300)); ?>" alt="<?php echo e($post->post_image); ?>">
                                    <?php elseif($post->post_type == 'video_file' OR $post->post_type == 'video_url' OR $post->post_type == 'video_embed'): ?>
                                        <img src="<?php echo e($videoHelper->showThumbnail($post, '300')); ?>" alt="<?php echo e($post->post_image); ?>">
                                        <div class="link-icon"><i class="fas fa-play"></i></div>
                                    <?php else: ?>
                                        <img src="<?php echo e($audioHelper->showThumbnail($post, '300')); ?>" alt="<?php echo e($post->post_image); ?>">
                                        <div class="link-icon"><i class="fas fa-music"></i></div>
                                    <?php endif; ?>
                                </a>
                            </figure>
                            <div class="details">
                                <div class="detail">
                                    <div class="category">
                                        <a href="<?php echo e(route('category.show', $category->slug)); ?>"><?php echo e($category->name); ?></a>
                                    </div>
                                    <div class="time"><?php echo e($post->created_at->locale(LaravelLocalization::getCurrentLocale())->isoFormat('LL')); ?></div>
                                    <div class="view"><?php echo e($post->post_hits); ?> <?php echo e(__('Laramagz::magz.views')); ?> &nbsp; <?php echo e($post->like); ?> <?php echo e(__('Laramagz::magz.likes')); ?></div>
                                </div>
                                <h1><a href="<?php echo e($postHelper->getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a></h1>
                                <p><?php echo \Str::limit(strip_tags($post->post_content), 150); ?></p>
                            </div>
                        </div>
                    </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 text-center">
                        <?php echo e($posts->links('frontend.magz.inc._pagination')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if($sidebarPosition === "right" AND $sidebarActive): ?>
                <?php echo $__env->make('frontend.magz.template-parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.magz.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/page/category.blade.php ENDPATH**/ ?>