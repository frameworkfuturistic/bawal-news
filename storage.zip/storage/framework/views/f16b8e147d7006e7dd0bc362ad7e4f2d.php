<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1><?php echo e($title); ?></h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('title.dashboard')); ?></a>
                    </li>
                    <?php $__currentLoopData = $addLink; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="breadcrumb-item">
                            <a href="<?php echo e($link); ?>"><?php echo e($label); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($currentActive)): ?>
                        <li class="breadcrumb-item active"><?php echo e($currentActive); ?></li>
                    <?php endif; ?>
                </ol>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/admin/breadcrumbs.blade.php ENDPATH**/ ?>