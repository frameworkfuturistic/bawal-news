<?php $postHelper = app('App\Helpers\PostHelper'); ?>

<?php if(count($posts)): ?>
<div class="block">
    <div class="block">
        <?php if($widgetData['title'] && Arr::exists($widgetData['title'], LaravelLocalization::getCurrentLocale())): ?>
        <h1 class="block-title"><?php echo e($widgetData['title'][LaravelLocalization::getCurrentLocale()]); ?></h1>
        <?php endif; ?>
        <div class="block-body">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="article-mini">
                    <div class="inner">
                        <figure>
                            <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                                <img src="<?php echo e($postHelper::showThumbnail($post, 80)); ?>" alt="<?php echo e($post->post_image); ?>">
                            </a>
                        </figure>
                        <div class="padding">
                            <h1><a href="<?php echo e($postHelper::getUriPost($post)); ?>"><?php echo e($post->post_title); ?></a></h1>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="d-grid gap-2">
                <a href="<?php echo e(route('articles.latest')); ?>" class="btn btn-magz white btn-block"><?php echo e(__('Laramagz::magz.see_all')); ?> &#8594;</a>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/footer/post-footer.blade.php ENDPATH**/ ?>