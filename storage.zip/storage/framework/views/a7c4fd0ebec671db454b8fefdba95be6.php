<?php if($active): ?>
    <?php if($layout == 'body'): ?>
        <?php if($widgetData['layout_type'] == 'two-column'): ?>
            <?php if (isset($component)) { $__componentOriginal417a48571e76c482cc479e5ca3ce7f1b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal417a48571e76c482cc479e5ca3ce7f1b = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Audio\TwoColumn::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('audio::two-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Audio\TwoColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal417a48571e76c482cc479e5ca3ce7f1b)): ?>
<?php $attributes = $__attributesOriginal417a48571e76c482cc479e5ca3ce7f1b; ?>
<?php unset($__attributesOriginal417a48571e76c482cc479e5ca3ce7f1b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal417a48571e76c482cc479e5ca3ce7f1b)): ?>
<?php $component = $__componentOriginal417a48571e76c482cc479e5ca3ce7f1b; ?>
<?php unset($__componentOriginal417a48571e76c482cc479e5ca3ce7f1b); ?>
<?php endif; ?>
        <?php elseif($widgetData['layout_type'] == 'one-column'): ?>
            <?php if (isset($component)) { $__componentOriginalaa0249124e2ad14c5d74f5020779d564 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa0249124e2ad14c5d74f5020779d564 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Audio\OneColumn::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('audio::one-column'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Audio\OneColumn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa0249124e2ad14c5d74f5020779d564)): ?>
<?php $attributes = $__attributesOriginalaa0249124e2ad14c5d74f5020779d564; ?>
<?php unset($__attributesOriginalaa0249124e2ad14c5d74f5020779d564); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa0249124e2ad14c5d74f5020779d564)): ?>
<?php $component = $__componentOriginalaa0249124e2ad14c5d74f5020779d564; ?>
<?php unset($__componentOriginalaa0249124e2ad14c5d74f5020779d564); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/audio.blade.php ENDPATH**/ ?>