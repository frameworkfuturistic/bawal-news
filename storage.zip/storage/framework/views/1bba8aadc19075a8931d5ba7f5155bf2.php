<div class="block-body no-margin">
    <ul class="footer-nav-horizontal">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e($menu['link']); ?>"><?php echo e($menu['label']); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/footer/menu-link.blade.php ENDPATH**/ ?>