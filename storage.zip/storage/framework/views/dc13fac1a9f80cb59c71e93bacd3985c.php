<script src="<?php echo e(asset('themes/magz/js/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/js/jquery.migrate.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/scripts/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/scripts/jquery-number/jquery.number.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/scripts/owlcarousel/dist/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/scripts/toast/jquery.toast.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/magz/js/e-magz.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>

<script>
function toSystemMode() {
    localStorage.theme = 'system';
    window.updateTheme();
}

function toDarkMode() {
    localStorage.theme = 'dark';
    window.updateTheme();
}

function toLightMode() {
    localStorage.theme = 'light';
    window.updateTheme();
}
</script>

<?php if(session('success')): ?>
<script>
// swal("Success", "<?php echo e(session('success')); ?>", "success");

Swal.fire({
  title: "",
  text: "<?php echo e(session('success')); ?>",
  icon: "success"
});

</script>
<?php endif; ?>

<?php if(session('error')): ?>
<script>
swal("Error", "<?php echo e(session('error')); ?>", "error");
</script>
<?php endif; ?>

<script>
jQuery.event.special.touchstart = {
    setup: function( _, ns, handle ) {
        this.addEventListener("touchstart", handle, { passive: !ns.includes("noPreventDefault") });
    }
};
jQuery.event.special.touchmove = {
    setup: function( _, ns, handle ) {
        this.addEventListener("touchmove", handle, { passive: !ns.includes("noPreventDefault") });
    }
};
jQuery.event.special.wheel = {
    setup: function( _, ns, handle ){
        this.addEventListener("wheel", handle, { passive: true });
    }
};
jQuery.event.special.mousewheel = {
    setup: function( _, ns, handle ){
        this.addEventListener("mousewheel", handle, { passive: true });
    }
};
</script><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/inc/_scripts.blade.php ENDPATH**/ ?>