<?php $termHelper = app('App\Helpers\TermHelper'); ?>
<?php $postHelper = app('App\Helpers\PostHelper'); ?>
<?php $posts->each(function ($posts) {$posts->load('categories'); }); ?>

<?php if(count($posts) AND $active): ?>
<div class="headline">
    <div class="nav" id="headline-nav">
        <a class="left carousel-control carousel-control-prev" role="button" data-slide="prev">
            <span class="arrow-left"></span>
            <span class="sr-only"><?php echo e(__('Laramagz::magz.previous')); ?></span>
        </a>
        <a class="right carousel-control carousel-control-next" role="button" data-slide="next">
            <span class="arrow-right"></span>
            <span class="sr-only"><?php echo e(__('Laramagz::magz.next')); ?></span>
        </a>
    </div>
    <div class="owl-carousel owl-theme" id="headline" data-autoplay="<?php echo e($autoPlay); ?>">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <a href="<?php echo e($postHelper::getUriPost($post)); ?>">
                    <?php if($post->categories->first() AND $post->categories->first()->name): ?>
                    <div class="badge">
                    <?php echo e($post->categories->first()->name); ?>

                    </div>
                    <?php endif; ?>
                    <?php echo e($post->post_title); ?>

                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/components/front/magz/headline.blade.php ENDPATH**/ ?>