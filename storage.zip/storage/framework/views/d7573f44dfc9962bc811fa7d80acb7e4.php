<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['page','layout','widgetName','widgetData']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['page','layout','widgetName','widgetData']); ?>
<?php foreach (array_filter((['page','layout','widgetName','widgetData']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal6fd7450cb79cf41a7930a461757ba4a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fd7450cb79cf41a7930a461757ba4a5 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Ads::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('ads'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Ads::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fd7450cb79cf41a7930a461757ba4a5)): ?>
<?php $attributes = $__attributesOriginal6fd7450cb79cf41a7930a461757ba4a5; ?>
<?php unset($__attributesOriginal6fd7450cb79cf41a7930a461757ba4a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fd7450cb79cf41a7930a461757ba4a5)): ?>
<?php $component = $__componentOriginal6fd7450cb79cf41a7930a461757ba4a5; ?>
<?php unset($__componentOriginal6fd7450cb79cf41a7930a461757ba4a5); ?>
<?php endif; ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\storage\framework\views/b13ef04b281547636a438ba463d68ae8.blade.php ENDPATH**/ ?>