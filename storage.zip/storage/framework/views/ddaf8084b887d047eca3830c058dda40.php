<script>
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
        }
    })
</script>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/layouts/partials/_csrf-token.blade.php ENDPATH**/ ?>