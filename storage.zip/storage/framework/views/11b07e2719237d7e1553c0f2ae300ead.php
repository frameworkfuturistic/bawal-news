<ul class="dropdown-menu">
    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php if($child['child']): ?>dropdown magz-dropdown <?php endif; ?>">
        <a href="<?php echo e($child['link']); ?>" title=""><?php echo e($child['label']); ?><?php if($child['child']): ?><i class="arrow-right"></i><?php endif; ?></a>

        <?php if( $child['child'] ): ?>
            <?php echo $__env->make('frontend.magz.inc._child',['childs' => $child['child']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/inc/_child.blade.php ENDPATH**/ ?>