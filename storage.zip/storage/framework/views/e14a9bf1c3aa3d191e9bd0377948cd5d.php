<?php extract(collect($attributes->getAttributes())->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['page','layout','widgetName','widgetData','localeId']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['page','layout','widgetName','widgetData','localeId']); ?>
<?php foreach (array_filter((['page','layout','widgetName','widgetData','localeId']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php if (isset($component)) { $__componentOriginal501e03743c9c987361175deb17cc1107 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal501e03743c9c987361175deb17cc1107 = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Post::resolve(['page' => $page,'layout' => $layout,'widgetName' => $widgetName,'widgetData' => $widgetData,'localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('post'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Post::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes)]); ?>

<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal501e03743c9c987361175deb17cc1107)): ?>
<?php $attributes = $__attributesOriginal501e03743c9c987361175deb17cc1107; ?>
<?php unset($__attributesOriginal501e03743c9c987361175deb17cc1107); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal501e03743c9c987361175deb17cc1107)): ?>
<?php $component = $__componentOriginal501e03743c9c987361175deb17cc1107; ?>
<?php unset($__componentOriginal501e03743c9c987361175deb17cc1107); ?>
<?php endif; ?><?php /**PATH D:\Projects\Web\laravel-news\bawal-news\storage\framework\views/2538766f4a1b3aaa8dae4f98cc158900.blade.php ENDPATH**/ ?>