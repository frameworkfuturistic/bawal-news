<?php $images = app('App\Helpers\ImageHelper'); ?>

<div class="firstbar">
    <div class="container-md">
        <div class="row">
            <div class="hidden-xs col-md-3 col-sm-12">
                <div class="brand">
                    <a href="/">
                        <img class="logo_dark" src="<?php echo e($images->webLogoLight()); ?>" alt="Web Logo" width="200" height="63">
                        <img class="logo_light" src="<?php echo e($images->webLogoDark()); ?>" alt="Web Logo" width="200" height="63">
                    </a>
                </div>
            </div>

            <div class="col-md-6 col-sm-12">
               <h1 class="display-1 text-white">Bawal News</h1>
               <p class="lead text-white">Stay updated with the latest headlines.</p>
            </div>


            
        </div>
    </div>
</div>

<!-- Start nav -->
<?php if (isset($component)) { $__componentOriginal4bf120a1d21feb972a0de7fd541032da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4bf120a1d21feb972a0de7fd541032da = $attributes; } ?>
<?php $component = App\View\Components\Front\Magz\Header\MenuHeader::resolve(['localeId' => $localeId] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Magz\Header\MenuHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4bf120a1d21feb972a0de7fd541032da)): ?>
<?php $attributes = $__attributesOriginal4bf120a1d21feb972a0de7fd541032da; ?>
<?php unset($__attributesOriginal4bf120a1d21feb972a0de7fd541032da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4bf120a1d21feb972a0de7fd541032da)): ?>
<?php $component = $__componentOriginal4bf120a1d21feb972a0de7fd541032da; ?>
<?php unset($__componentOriginal4bf120a1d21feb972a0de7fd541032da); ?>
<?php endif; ?>
<!-- End nav -->
<?php /**PATH D:\Projects\Web\laravel-news\bawal-news\resources\views/frontend/magz/template-parts/header.blade.php ENDPATH**/ ?>